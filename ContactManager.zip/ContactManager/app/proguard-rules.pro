# قوانین پیش‌فرض Proguard/R8
-keep class com.example.contactmanager.data.** { *; }
