package com.example.contactmanager.viewmodel

import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.contactmanager.data.Contact
import com.example.contactmanager.data.ContactRepository
import com.example.contactmanager.util.PhonePatternUtil
import com.example.contactmanager.util.VCardUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class ImportExportState {
    object Idle : ImportExportState()
    object Loading : ImportExportState()
    data class ImportSuccess(val count: Int, val fileCount: Int = 1) : ImportExportState()
    data class ExportSuccess(val count: Int) : ImportExportState()
    data class Error(val message: String) : ImportExportState()
}

sealed class ActionMessage {
    data class SelectedDeleted(val count: Int) : ActionMessage()
    data class DuplicatesRemoved(val count: Int) : ActionMessage()
}

class ContactViewModel(private val repository: ContactRepository) : ViewModel() {

    private val searchQuery = MutableStateFlow("")

    val contactCount = repository.contactCount.asLiveData()

    private val _importExportState = MutableStateFlow<ImportExportState>(ImportExportState.Idle)
    val importExportState: Flow<ImportExportState> = _importExportState.asStateFlow()

    // پیام‌های کوتاه مربوط به عملیات (حذف دسته‌جمعی، حذف تکراری‌ها و ...)
    private val _actionMessage = MutableStateFlow<ActionMessage?>(null)
    val actionMessage: Flow<ActionMessage?> = _actionMessage.asStateFlow()

    // جریان مخاطبین صفحه‌بندی‌شده که با تغییر متن جستجو به‌روز می‌شود
    @OptIn(kotlinx.coroutines.FlowPreview::class)
    val contacts: Flow<PagingData<Contact>> = searchQuery
        .debounce(300)
        .distinctUntilChanged()
        .flatMapLatest { query ->
            when {
                query.isBlank() -> repository.getAllContacts()
                // اگر متن جستجو شامل x/X در کنار ارقام باشد، جستجوی الگویی شماره انجام می‌شود
                // (مثال: 091454xxx11 یا 914xxx2111 -> ارقام x هرچیزی می‌توانند باشند)
                PhonePatternUtil.isPatternQuery(query) -> {
                    val (pattern, length) = PhonePatternUtil.buildNormalizedLikePattern(query)
                    repository.searchContactsByPhonePattern(pattern, length)
                }
                else -> repository.searchContacts(query)
            }
        }
        .cachedIn(viewModelScope)

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun addContact(name: String, phone: String, email: String?) {
        viewModelScope.launch {
            repository.insert(Contact(name = name, phone = phone, email = email))
        }
    }

    fun updateContact(contact: Contact) {
        viewModelScope.launch {
            repository.update(contact)
        }
    }

    fun deleteContact(contact: Contact) {
        viewModelScope.launch {
            repository.delete(contact)
        }
    }

    fun deleteAllContacts() {
        viewModelScope.launch {
            repository.deleteAll()
        }
    }

    /** حذف دسته‌جمعی مخاطبین انتخاب‌شده */
    fun deleteSelectedContacts(ids: List<Long>) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.deleteByIds(ids)
            _actionMessage.value = ActionMessage.SelectedDeleted(ids.size)
        }
    }

    /** حذف مخاطبین با شماره تکراری (فقط قدیمی‌ترین رکورد هر شماره نگه داشته می‌شود) */
    fun removeDuplicateContacts() {
        viewModelScope.launch {
            val removed = withContext(Dispatchers.IO) { repository.removeDuplicateContacts() }
            _actionMessage.value = ActionMessage.DuplicatesRemoved(removed)
        }
    }

    fun clearActionMessage() {
        _actionMessage.value = null
    }

    /** وارد کردن یک یا چند فایل VCF به‌صورت هم‌زمان */
    fun importFromVCard(contentResolver: ContentResolver, uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _importExportState.value = ImportExportState.Loading
            try {
                var totalImported = 0
                withContext(Dispatchers.IO) {
                    for (uri in uris) {
                        val contacts = contentResolver.openInputStream(uri)?.use { input ->
                            VCardUtil.parseVCard(input)
                        } ?: emptyList()
                        if (contacts.isNotEmpty()) {
                            repository.insertContactsBatch(contacts)
                            totalImported += contacts.size
                        }
                    }
                }
                if (totalImported == 0) {
                    _importExportState.value = ImportExportState.Error("مخاطبی در فایل‌های انتخاب‌شده یافت نشد")
                } else {
                    _importExportState.value = ImportExportState.ImportSuccess(totalImported, uris.size)
                }
            } catch (e: Exception) {
                _importExportState.value = ImportExportState.Error(e.message ?: "خطا در واردات فایل")
            }
        }
    }

    fun exportToVCard(contentResolver: ContentResolver, uri: Uri) {
        viewModelScope.launch {
            _importExportState.value = ImportExportState.Loading
            try {
                val allContacts = withContext(Dispatchers.IO) {
                    repository.getAllContactsForExport()
                }
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { output ->
                        VCardUtil.writeVCard(output, allContacts)
                    }
                }
                _importExportState.value = ImportExportState.ExportSuccess(allContacts.size)
            } catch (e: Exception) {
                _importExportState.value = ImportExportState.Error(e.message ?: "خطا در صادرات فایل")
            }
        }
    }

    fun resetImportExportState() {
        _importExportState.value = ImportExportState.Idle
    }
}

class ContactViewModelFactory(private val repository: ContactRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ContactViewModel::class.java)) {
            return ContactViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
