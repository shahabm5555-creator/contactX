package com.example.contactmanager.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * مدل داده‌ای یک مخاطب.
 * ایندکس روی name و phone برای سرعت بالای جستجو حتی با تعداد بسیار زیاد رکورد.
 */
@Entity(
    tableName = "contacts",
    indices = [Index(value = ["name"]), Index(value = ["phone"])]
)
data class Contact(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "phone")
    val phone: String,

    @ColumnInfo(name = "email")
    val email: String? = null,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)
