package com.example.contactmanager

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.contactmanager.data.Contact
import com.example.contactmanager.databinding.ActivityMainBinding
import com.example.contactmanager.ui.ContactAdapter
import com.example.contactmanager.viewmodel.ActionMessage
import com.example.contactmanager.viewmodel.ContactViewModel
import com.example.contactmanager.viewmodel.ContactViewModelFactory
import com.example.contactmanager.viewmodel.ImportExportState
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val viewModel: ContactViewModel by lazy {
        ViewModelProvider(
            this,
            ContactViewModelFactory((application as ContactManagerApp).repository)
        )[ContactViewModel::class.java]
    }

    private lateinit var adapter: ContactAdapter

    // انتخاب یک یا چند فایل VCF به‌صورت هم‌زمان
    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.importFromVCard(contentResolver, uris)
        }
    }

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/x-vcard")
    ) { uri ->
        uri?.let { viewModel.exportToVCard(contentResolver, it) }
    }

    private val addEditLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { /* لیست به‌صورت خودکار از طریق Flow به‌روزرسانی می‌شود */ }

    private val selectionBackCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            exitSelectionMode()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        onBackPressedDispatcher.addCallback(this, selectionBackCallback)

        setupRecyclerView()
        setupSearch()
        setupFab()
        observeContactCount()
        observeImportExportState()
        observeActionMessage()
    }

    private fun setupRecyclerView() {
        adapter = ContactAdapter(
            onItemClick = { contact -> openEditContact(contact) },
            onDeleteClick = { contact -> confirmDelete(contact) },
            onItemLongClick = { contact -> enterSelectionMode(contact) },
            onSelectionChanged = { updateSelectionToolbar() }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        lifecycleScope.launch {
            viewModel.contacts.collect { pagingData ->
                adapter.submitData(pagingData)
            }
        }
    }

    private fun setupSearch() {
        binding.editSearch.addTextChangedListener { text ->
            viewModel.setSearchQuery(text?.toString().orEmpty())
        }
    }

    private fun setupFab() {
        binding.fabAdd.setOnClickListener {
            val intent = Intent(this, AddEditContactActivity::class.java)
            addEditLauncher.launch(intent)
        }
    }

    private fun openEditContact(contact: Contact) {
        val intent = Intent(this, AddEditContactActivity::class.java).apply {
            putExtra(AddEditContactActivity.EXTRA_CONTACT_ID, contact.id)
            putExtra(AddEditContactActivity.EXTRA_CONTACT_NAME, contact.name)
            putExtra(AddEditContactActivity.EXTRA_CONTACT_PHONE, contact.phone)
            putExtra(AddEditContactActivity.EXTRA_CONTACT_EMAIL, contact.email)
        }
        addEditLauncher.launch(intent)
    }

    private fun confirmDelete(contact: Contact) {
        AlertDialog.Builder(this)
            .setTitle("حذف مخاطب")
            .setMessage("آیا از حذف «${contact.name}» مطمئن هستید؟")
            .setPositiveButton("حذف") { _, _ -> viewModel.deleteContact(contact) }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // ---------- حالت انتخاب دسته‌جمعی ----------

    private fun enterSelectionMode(contact: Contact) {
        adapter.enterSelectionMode(contact.id)
        selectionBackCallback.isEnabled = true
        binding.fabAdd.visibility = View.GONE
        updateSelectionToolbar()
        invalidateOptionsMenu()
        refreshVisibleItems()
    }

    private fun exitSelectionMode() {
        adapter.exitSelectionMode()
        selectionBackCallback.isEnabled = false
        binding.fabAdd.visibility = View.VISIBLE
        binding.toolbar.title = getString(R.string.app_name)
        invalidateOptionsMenu()
        refreshVisibleItems()
    }

    /**
     * فقط ردیف‌هایی که همین الان روی صفحه دیده می‌شوند را دوباره bind می‌کند
     * (نه کل چند ده‌هزار مخاطب) تا هنگام ورود/خروج از حالت انتخاب، مشکلی در
     * اندازه یا کارایی لیست پیش نیاید.
     */
    private fun refreshVisibleItems() {
        val layoutManager = binding.recyclerView.layoutManager as? LinearLayoutManager ?: return
        val first = layoutManager.findFirstVisibleItemPosition()
        val last = layoutManager.findLastVisibleItemPosition()
        if (first != androidx.recyclerview.widget.RecyclerView.NO_POSITION &&
            last != androidx.recyclerview.widget.RecyclerView.NO_POSITION && last >= first
        ) {
            adapter.notifyItemRangeChanged(first, last - first + 1)
        }
    }

    private fun updateSelectionToolbar() {
        val count = adapter.getSelectedCount()
        if (count == 0) {
            exitSelectionMode()
        } else {
            binding.toolbar.title = getString(R.string.selection_count_format, count)
        }
    }

    private fun confirmDeleteSelected() {
        val ids = adapter.getSelectedIds()
        if (ids.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_contact)
            .setMessage(getString(R.string.delete_selected_confirm_format, ids.size))
            .setPositiveButton(R.string.delete) { _, _ ->
                viewModel.deleteSelectedContacts(ids)
                exitSelectionMode()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------- مشاهده وضعیت‌ها ----------

    private fun observeContactCount() {
        viewModel.contactCount.observe(this) { count ->
            binding.textContactCount.text = getString(R.string.contact_count_format, count)
        }
    }

    private fun observeImportExportState() {
        lifecycleScope.launch {
            viewModel.importExportState.collect { state ->
                when (state) {
                    is ImportExportState.Loading -> {
                        binding.progressBar.visibility = View.VISIBLE
                    }
                    is ImportExportState.ImportSuccess -> {
                        binding.progressBar.visibility = View.GONE
                        val message = if (state.fileCount > 1) {
                            "${state.count} مخاطب از ${state.fileCount} فایل با موفقیت وارد شد"
                        } else {
                            "${state.count} مخاطب با موفقیت وارد شد"
                        }
                        Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                        viewModel.resetImportExportState()
                    }
                    is ImportExportState.ExportSuccess -> {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(this@MainActivity, "${state.count} مخاطب با موفقیت صادر شد", Toast.LENGTH_SHORT).show()
                        viewModel.resetImportExportState()
                    }
                    is ImportExportState.Error -> {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(this@MainActivity, "خطا: ${state.message}", Toast.LENGTH_LONG).show()
                        viewModel.resetImportExportState()
                    }
                    is ImportExportState.Idle -> {
                        binding.progressBar.visibility = View.GONE
                    }
                }
            }
        }
    }

    private fun observeActionMessage() {
        lifecycleScope.launch {
            viewModel.actionMessage.collect { message ->
                when (message) {
                    is ActionMessage.SelectedDeleted -> {
                        Toast.makeText(this@MainActivity, getString(R.string.deleted_selected_format, message.count), Toast.LENGTH_SHORT).show()
                        viewModel.clearActionMessage()
                    }
                    is ActionMessage.DuplicatesRemoved -> {
                        val text = if (message.count > 0) {
                            getString(R.string.duplicates_removed_format, message.count)
                        } else {
                            getString(R.string.no_duplicates_found)
                        }
                        Toast.makeText(this@MainActivity, text, Toast.LENGTH_SHORT).show()
                        viewModel.clearActionMessage()
                    }
                    null -> Unit
                }
            }
        }
    }

    // ---------- منو ----------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.clear()
        if (adapter.selectionModeEnabled) {
            menuInflater.inflate(R.menu.selection_menu, menu)
        } else {
            menuInflater.inflate(R.menu.main_menu, menu)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_import -> {
                importLauncher.launch(arrayOf("text/x-vcard", "text/vcard", "*/*"))
                true
            }
            R.id.action_export -> {
                val fileName = "contacts_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.vcf"
                exportLauncher.launch(fileName)
                true
            }
            R.id.action_delete_all -> {
                confirmDeleteAll()
                true
            }
            R.id.action_remove_duplicates -> {
                viewModel.removeDuplicateContacts()
                true
            }
            R.id.action_about -> {
                startActivity(Intent(this, AboutActivity::class.java))
                true
            }
            R.id.action_cancel_selection -> {
                exitSelectionMode()
                true
            }
            R.id.action_delete_selected -> {
                confirmDeleteSelected()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun confirmDeleteAll() {
        AlertDialog.Builder(this)
            .setTitle("حذف همه مخاطبین")
            .setMessage("این عملیات غیرقابل بازگشت است. آیا مطمئن هستید؟")
            .setPositiveButton("حذف همه") { _, _ ->
                viewModel.deleteAllContacts()
                Toast.makeText(this, "همه مخاطبین حذف شدند", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }
}

// Extension ساده برای addTextChangedListener بدون وابستگی به core-ktx-widget
private fun android.widget.EditText.addTextChangedListener(onChange: (CharSequence?) -> Unit) {
    this.addTextChangedListener(object : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            onChange(s)
        }
        override fun afterTextChanged(s: android.text.Editable?) {}
    })
}
