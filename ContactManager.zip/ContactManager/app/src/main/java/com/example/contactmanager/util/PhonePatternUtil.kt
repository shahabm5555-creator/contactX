package com.example.contactmanager.util

/**
 * ابزار جستجوی الگویی شماره تلفن.
 * کاربر می‌تواند به‌جای ارقام نامشخص از حرف x یا X استفاده کند، مثلاً:
 *   091454xxx11   -> سه رقم وسط هرچیزی می‌تواند باشد، بقیه ارقام دقیقاً باید مطابقت داشته باشند
 *   0913xxx2111   -> سه رقم بعد از 0913 هرچیزی می‌تواند باشد
 *
 * هر x دقیقاً معادل یک رقم ناشناخته است (نه بیشتر، نه کمتر) و طول کل شماره باید با
 * طول الگو برابر باشد.
 */
object PhonePatternUtil {

    /**
     * تشخیص می‌دهد آیا متن ورودی یک الگوی جستجوی شماره است (شامل رقم و x/X باشد
     * و حداقل یک x در آن وجود داشته باشد).
     */
    fun isPatternQuery(raw: String): Boolean {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return false
        val hasWildcard = trimmed.any { it == 'x' || it == 'X' }
        val onlyDigitsAndWildcard = trimmed.all { it.isDigit() || it == 'x' || it == 'X' || it == ' ' }
        return hasWildcard && onlyDigitsAndWildcard
    }

    /**
     * متن ورودی کاربر (مثل 091454xxx11 یا 914xxx2111) را به یک الگوی SQL LIKE امن تبدیل می‌کند
     * و همزمان آن را به «۱۰ رقم آخر» نرمال می‌کند (بدون + و بدون صفر ابتدایی/کد کشور)،
     * دقیقاً هم‌شکل با نرمال‌سازی شماره‌های ذخیره‌شده تا مطابقت درست انجام شود.
     * خروجی: جفت (الگوی LIKE، طول الگو) که مستقیماً برای مقایسه با انتهای شماره نرمال‌شده استفاده می‌شود.
     */
    fun buildNormalizedLikePattern(raw: String): Pair<String, Int> {
        val cleaned = raw.trim().replace(" ", "").removePrefix("+")
        val builder = StringBuilder()
        for (ch in cleaned) {
            when (ch) {
                '\\', '%', '_' -> {
                    builder.append('\\')
                    builder.append(ch)
                }
                'x', 'X' -> builder.append('_')
                else -> builder.append(ch)
            }
        }
        var result = builder.toString()
        if (result.length > 10) {
            result = result.takeLast(10)
        }
        return result to result.length
    }

    /**
     * متن ورودی کاربر (مثل 091454xxx11) را به یک الگوی SQL LIKE امن تبدیل می‌کند
     * که هر x به '_' (یک کاراکتر ناشناخته در SQLite) تبدیل می‌شود.
     * کاراکترهای خاص LIKE (% _ \) در صورت وجود escape می‌شوند تا در جستجو مشکلی ایجاد نکنند.
     */
    fun buildLikePattern(raw: String): String {
        val cleaned = raw.trim().replace(" ", "")
        val builder = StringBuilder()
        for (ch in cleaned) {
            when (ch) {
                '\\', '%', '_' -> {
                    builder.append('\\')
                    builder.append(ch)
                }
                'x', 'X' -> builder.append('_')
                else -> builder.append(ch)
            }
        }
        return builder.toString()
    }
}
