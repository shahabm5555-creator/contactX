package com.example.contactmanager.util

/**
 * ابزار نرمال‌سازی شماره تلفن برای جستجو، صرف‌نظر از پیش‌شماره کشور یا صفر ابتدایی.
 * مثال: هم "+989194063450" و هم "09194063450" به شکل یکسان "9194063450" نرمال می‌شوند.
 */
object PhoneNormalizer {

    /**
     * ۱۰ رقم آخر شماره را برمی‌گرداند (بدون + و بدون فاصله).
     * اگر شماره کمتر از ۱۰ رقم داشته باشد، همان ارقام موجود برگردانده می‌شود
     * (برای پشتیبانی از جستجوی تدریجی هنگام تایپ).
     */
    fun last10Digits(input: String): String {
        val digitsOnly = input.filter { it.isDigit() }
        if (digitsOnly.isEmpty()) return ""
        return if (digitsOnly.length > 10) {
            digitsOnly.takeLast(10)
        } else {
            digitsOnly
        }
    }
}
