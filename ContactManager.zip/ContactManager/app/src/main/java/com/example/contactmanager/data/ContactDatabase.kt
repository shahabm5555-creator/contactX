package com.example.contactmanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [Contact::class], version = 2, exportSchema = false)
abstract class ContactDatabase : RoomDatabase() {

    abstract fun contactDao(): ContactDao

    companion object {
        @Volatile
        private var INSTANCE: ContactDatabase? = null

        fun getInstance(context: Context): ContactDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ContactDatabase::class.java,
                    "contact_manager.db"
                )
                    // WAL برای خواندن/نوشتن همزمان و کارایی بهتر با حجم داده بالا
                    .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
                    // چون در مرحله تست هستیم و ساختار جدول تغییر کرده (ایندکس یکتای شماره)،
                    // در صورت آپدیت نسخه، دیتابیس قدیمی پاک و از نو ساخته می‌شود
                    .fallbackToDestructiveMigration()
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onOpen(db: SupportSQLiteDatabase) {
                            super.onOpen(db)
                            db.execSQL("PRAGMA synchronous = NORMAL")
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
