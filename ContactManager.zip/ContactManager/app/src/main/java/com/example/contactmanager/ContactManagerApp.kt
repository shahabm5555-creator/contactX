package com.example.contactmanager

import android.app.Application
import com.example.contactmanager.data.ContactDatabase
import com.example.contactmanager.data.ContactRepository

class ContactManagerApp : Application() {

    val repository: ContactRepository by lazy {
        ContactRepository(ContactDatabase.getInstance(this).contactDao())
    }
}
