package com.example.contactmanager.util

import com.example.contactmanager.data.Contact
import java.io.BufferedReader
import java.io.InputStream
import java.io.OutputStream
import java.io.OutputStreamWriter

/**
 * ابزار سبک برای Import/Export فایل‌های vCard (نسخه ۲.۱ و ۳.۰)
 * بدون نیاز به کتابخانه خارجی، برای پشتیبانی از فایل‌های بزرگ به‌صورت استریم.
 */
object VCardUtil {

    /**
     * فایل VCF را به‌صورت استریم می‌خواند تا فایل‌های بسیار بزرگ حافظه را پر نکنند.
     */
    fun parseVCard(inputStream: InputStream): List<Contact> {
        val contacts = mutableListOf<Contact>()
        var name: String? = null
        var phone: String? = null
        var email: String? = null

        inputStream.bufferedReader(Charsets.UTF_8).use { reader: BufferedReader ->
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val trimmed = line?.trim() ?: continue
                when {
                    trimmed.equals("BEGIN:VCARD", ignoreCase = true) -> {
                        name = null; phone = null; email = null
                    }
                    trimmed.startsWith("FN:", ignoreCase = true) -> {
                        name = trimmed.substringAfter(":").trim()
                    }
                    trimmed.startsWith("N:", ignoreCase = true) && name == null -> {
                        // فرمت N: نام‌خانوادگی;نام;...
                        val parts = trimmed.substringAfter(":").split(";")
                        name = parts.filter { it.isNotBlank() }
                            .joinToString(" ")
                            .ifBlank { null }
                    }
                    trimmed.startsWith("TEL", ignoreCase = true) -> {
                        val value = trimmed.substringAfter(":").trim()
                        if (value.isNotBlank()) phone = value
                    }
                    trimmed.startsWith("EMAIL", ignoreCase = true) -> {
                        val value = trimmed.substringAfter(":").trim()
                        if (value.isNotBlank()) email = value
                    }
                    trimmed.equals("END:VCARD", ignoreCase = true) -> {
                        val finalName = name ?: "بدون نام"
                        val finalPhone = phone
                        if (!finalPhone.isNullOrBlank()) {
                            contacts.add(
                                Contact(
                                    name = finalName,
                                    phone = finalPhone,
                                    email = email
                                )
                            )
                        }
                    }
                }
            }
        }
        return contacts
    }

    /**
     * لیست مخاطبین را به‌صورت استریم در فایل VCF می‌نویسد.
     */
    fun writeVCard(outputStream: OutputStream, contacts: List<Contact>) {
        OutputStreamWriter(outputStream, Charsets.UTF_8).use { writer ->
            for (contact in contacts) {
                writer.append("BEGIN:VCARD\r\n")
                writer.append("VERSION:3.0\r\n")
                writer.append("FN:${escape(contact.name)}\r\n")
                writer.append("N:${escape(contact.name)};;;;\r\n")
                writer.append("TEL;TYPE=CELL:${escape(contact.phone)}\r\n")
                if (!contact.email.isNullOrBlank()) {
                    writer.append("EMAIL:${escape(contact.email)}\r\n")
                }
                writer.append("END:VCARD\r\n")
            }
            writer.flush()
        }
    }

    private fun escape(value: String): String {
        return value
            .replace("\\", "\\\\")
            .replace(",", "\\,")
            .replace(";", "\\;")
    }
}
