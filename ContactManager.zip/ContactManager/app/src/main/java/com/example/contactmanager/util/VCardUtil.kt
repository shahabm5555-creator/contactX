package com.example.contactmanager.util

import com.example.contactmanager.data.Contact
import java.io.InputStream
import java.io.OutputStream
import java.io.OutputStreamWriter

/**
 * ابزار سبک برای Import/Export فایل‌های vCard (نسخه ۲.۱ و ۳.۰)
 * بدون نیاز به کتابخانه خارجی، برای پشتیبانی از فایل‌های بزرگ.
 *
 * برخی گوشی‌ها/اپلیکیشن‌ها نام مخاطب را به‌جای متن ساده UTF-8، با رمزنگاری
 * QUOTED-PRINTABLE ذخیره می‌کنند (رایج برای زبان‌های غیرلاتین مثل فارسی)، مثال:
 *   FN;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:=D8=B9=D9=84=DB=8C
 * این کلاس این فرمت را هم تشخیص و دیکد می‌کند تا اسامی فارسی به‌درستی خوانده شوند.
 */
object VCardUtil {

    /**
     * فایل VCF را می‌خواند. خطوط تاخورده (RFC 2425 line folding) و مقادیر
     * QUOTED-PRINTABLE به‌درستی بازسازی و دیکد می‌شوند.
     */
    fun parseVCard(inputStream: InputStream): List<Contact> {
        val contacts = mutableListOf<Contact>()

        // مرحله ۱: خواندن همه خطوط و باز کردن خطوط تاخورده
        // (خطی که با فاصله یا Tab شروع شود، ادامه‌ی خط قبلی است)
        val rawLines = inputStream.bufferedReader(Charsets.UTF_8).readLines()
        val unfolded = mutableListOf<String>()
        for (line in rawLines) {
            if ((line.startsWith(" ") || line.startsWith("\t")) && unfolded.isNotEmpty()) {
                unfolded[unfolded.size - 1] = unfolded.last() + line.substring(1)
            } else {
                unfolded.add(line)
            }
        }

        var name: String? = null
        var phone: String? = null
        var email: String? = null

        var i = 0
        while (i < unfolded.size) {
            val rawLine = unfolded[i].trimEnd('\r', '\n')
            val trimmed = rawLine.trim()

            when {
                trimmed.equals("BEGIN:VCARD", ignoreCase = true) -> {
                    name = null; phone = null; email = null
                }
                trimmed.equals("END:VCARD", ignoreCase = true) -> {
                    val finalPhone = phone
                    if (!finalPhone.isNullOrBlank()) {
                        // اگر فایل VCF به‌جای نام واقعی، خود شماره تلفن را به‌عنوان نام
                        // ذخیره کرده باشد (رایج در بعضی اپلیکیشن‌ها برای مخاطبین بدون نام)،
                        // به‌جای نمایش عدد تکراری، «بدون نام» نشان داده می‌شود
                        val nameDigits = name?.filter { it.isDigit() }
                        val phoneDigits = finalPhone.filter { it.isDigit() }
                        val looksLikePhoneNumber =
                            !nameDigits.isNullOrBlank() && nameDigits.length >= 7 &&
                                (nameDigits == phoneDigits || phoneDigits.endsWith(nameDigits) || nameDigits.endsWith(phoneDigits))

                        val finalName = when {
                            name.isNullOrBlank() -> "بدون نام"
                            looksLikePhoneNumber -> "بدون نام"
                            else -> name!!
                        }

                        contacts.add(
                            Contact(
                                name = finalName,
                                phone = finalPhone,
                                email = email
                            )
                        )
                    }
                }
                else -> {
                    val colonIndex = trimmed.indexOf(':')
                    if (colonIndex > 0) {
                        // propertyPart مثل "FN" یا "N;ENCODING=QUOTED-PRINTABLE;CHARSET=UTF-8" یا "TEL;TYPE=CELL"
                        val propertyPart = trimmed.substring(0, colonIndex)
                        var value = trimmed.substring(colonIndex + 1)
                        val propertyName = propertyPart.substringBefore(";").trim().uppercase()
                        val isQuotedPrintable = propertyPart.contains("QUOTED-PRINTABLE", ignoreCase = true)

                        if (isQuotedPrintable) {
                            // خطوط QUOTED-PRINTABLE ممکن است با '=' در انتها ادامه پیدا کنند (soft line break)
                            val sb = StringBuilder(value)
                            while (sb.isNotEmpty() && sb.last() == '=' && i + 1 < unfolded.size) {
                                sb.setLength(sb.length - 1)
                                i++
                                sb.append(unfolded[i].trimEnd('\r', '\n'))
                            }
                            val charsetName = Regex("CHARSET=([^;:]+)", RegexOption.IGNORE_CASE)
                                .find(propertyPart)?.groupValues?.get(1) ?: "UTF-8"
                            value = decodeQuotedPrintable(sb.toString(), charsetName)
                        }

                        when (propertyName) {
                            "FN" -> if (value.isNotBlank()) name = value.trim()
                            "N" -> if (name == null && value.isNotBlank()) {
                                val parts = value.split(";")
                                val joined = parts.filter { it.isNotBlank() }.joinToString(" ")
                                if (joined.isNotBlank()) name = joined
                            }
                            "TEL" -> if (value.isNotBlank()) phone = value.trim()
                            "EMAIL" -> if (value.isNotBlank()) email = value.trim()
                        }
                    }
                }
            }
            i++
        }
        return contacts
    }

    /**
     * دیکد کردن رشته QUOTED-PRINTABLE (مثل =D8=B9=D9=84=DB=8C) به متن اصلی
     * با در نظر گرفتن charset مشخص‌شده (پیش‌فرض UTF-8).
     */
    private fun decodeQuotedPrintable(input: String, charsetName: String): String {
        val bytes = mutableListOf<Byte>()
        var idx = 0
        while (idx < input.length) {
            val c = input[idx]
            if (c == '=' && idx + 2 < input.length) {
                val hex = input.substring(idx + 1, idx + 3)
                val byteVal = hex.toIntOrNull(16)
                if (byteVal != null) {
                    bytes.add(byteVal.toByte())
                    idx += 3
                    continue
                }
            }
            // کاراکتر معمولی (غیر رمزنگاری‌شده)
            bytes.add(c.code.toByte())
            idx++
        }
        return try {
            String(bytes.toByteArray(), charset(charsetName))
        } catch (e: Exception) {
            String(bytes.toByteArray(), Charsets.UTF_8)
        }
    }

    /**
     * لیست مخاطبین را به‌صورت استریم در فایل VCF می‌نویسد.
     */
    fun writeVCard(outputStream: OutputStream, contacts: List<Contact>) {
        OutputStreamWriter(outputStream, Charsets.UTF_8).use { writer ->
            for (contact in contacts) {
                writer.append("BEGIN:VCARD\r\n")
                writer.append("VERSION:3.0\r\n")
                writer.append("FN:${escape(contact.name)}\r\n")
                writer.append("N:${escape(contact.name)};;;;\r\n")
                writer.append("TEL;TYPE=CELL:${escape(contact.phone)}\r\n")
                if (!contact.email.isNullOrBlank()) {
                    writer.append("EMAIL:${escape(contact.email)}\r\n")
                }
                writer.append("END:VCARD\r\n")
            }
            writer.flush()
        }
    }

    private fun escape(value: String): String {
        return value
            .replace("\\", "\\\\")
            .replace(",", "\\,")
            .replace(";", "\\;")
    }
}
