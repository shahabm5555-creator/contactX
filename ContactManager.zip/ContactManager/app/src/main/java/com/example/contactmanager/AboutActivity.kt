package com.example.contactmanager

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.contactmanager.databinding.ActivityAboutBinding

class AboutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.textVersion.text = getString(R.string.about_version_format, BuildConfig.VERSION_NAME)

        binding.buttonSupport.setOnClickListener {
            openTelegramSupport()
        }
    }

    private fun openTelegramSupport() {
        val telegramUsername = "shahabm5555"
        try {
            // ابتدا سعی می‌کند مستقیم داخل اپلیکیشن تلگرام باز شود
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?domain=$telegramUsername")))
        } catch (e: ActivityNotFoundException) {
            try {
                // در صورت نبود اپلیکیشن تلگرام، از طریق مرورگر باز می‌شود
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/$telegramUsername")))
            } catch (e: Exception) {
                Toast.makeText(this, "امکان باز کردن تلگرام وجود ندارد", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
