package com.example.contactmanager

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.contactmanager.data.Contact
import com.example.contactmanager.databinding.ActivityAddEditContactBinding
import com.example.contactmanager.viewmodel.ContactViewModel
import com.example.contactmanager.viewmodel.ContactViewModelFactory

class AddEditContactActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddEditContactBinding
    private var contactId: Long = -1L

    private val viewModel: ContactViewModel by lazy {
        ViewModelProvider(
            this,
            ContactViewModelFactory((application as ContactManagerApp).repository)
        )[ContactViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditContactBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        contactId = intent.getLongExtra(EXTRA_CONTACT_ID, -1L)
        val isEdit = contactId != -1L

        supportActionBar?.title = if (isEdit) getString(R.string.edit_contact) else getString(R.string.add_contact)

        if (isEdit) {
            binding.editName.setText(intent.getStringExtra(EXTRA_CONTACT_NAME))
            binding.editPhone.setText(intent.getStringExtra(EXTRA_CONTACT_PHONE))
            binding.editEmail.setText(intent.getStringExtra(EXTRA_CONTACT_EMAIL))
            binding.buttonDelete.visibility = android.view.View.VISIBLE
        }

        binding.buttonSave.setOnClickListener { saveContact(isEdit) }
        binding.buttonDelete.setOnClickListener { confirmDelete() }
    }

    private fun saveContact(isEdit: Boolean) {
        val name = binding.editName.text.toString().trim()
        val phone = binding.editPhone.text.toString().trim()
        val email = binding.editEmail.text.toString().trim().ifBlank { null }

        if (name.isBlank()) {
            binding.editName.error = getString(R.string.error_name_required)
            return
        }
        if (phone.isBlank()) {
            binding.editPhone.error = getString(R.string.error_phone_required)
            return
        }

        if (isEdit) {
            viewModel.updateContact(Contact(id = contactId, name = name, phone = phone, email = email))
        } else {
            viewModel.addContact(name, phone, email)
        }
        Toast.makeText(this, getString(R.string.saved_successfully), Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_contact)
            .setMessage(R.string.delete_confirm_message)
            .setPositiveButton(R.string.delete) { _, _ ->
                viewModel.deleteContact(
                    Contact(
                        id = contactId,
                        name = binding.editName.text.toString(),
                        phone = binding.editPhone.text.toString()
                    )
                )
                finish()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    companion object {
        const val EXTRA_CONTACT_ID = "extra_contact_id"
        const val EXTRA_CONTACT_NAME = "extra_contact_name"
        const val EXTRA_CONTACT_PHONE = "extra_contact_phone"
        const val EXTRA_CONTACT_EMAIL = "extra_contact_email"
    }
}
