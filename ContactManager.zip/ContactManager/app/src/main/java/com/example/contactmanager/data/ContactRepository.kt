package com.example.contactmanager.data

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.example.contactmanager.util.PhoneNormalizer
import kotlinx.coroutines.flow.Flow

class ContactRepository(private val dao: ContactDao) {

    val contactCount: Flow<Int> = dao.getContactCount()

    fun getAllContacts(): Flow<PagingData<Contact>> {
        return Pager(
            config = PagingConfig(
                pageSize = 50,
                enablePlaceholders = true,
                maxSize = 200
            ),
            pagingSourceFactory = { dao.getAllContactsPaged() }
        ).flow
    }

    fun searchContacts(query: String): Flow<PagingData<Contact>> {
        val trimmedQuery = query.trim()
        val phoneDigits = PhoneNormalizer.last10Digits(trimmedQuery)
        return Pager(
            config = PagingConfig(
                pageSize = 50,
                enablePlaceholders = true,
                maxSize = 200
            ),
            pagingSourceFactory = { dao.searchContactsPaged(trimmedQuery, phoneDigits) }
        ).flow
    }

    /**
     * جستجوی الگویی شماره تلفن. pattern باید از قبل با PhonePatternUtil ساخته شده باشد
     * (هر رقم ناشناخته با کاراکتر '_' مشخص می‌شود).
     */
    fun searchContactsByPhonePattern(pattern: String): Flow<PagingData<Contact>> {
        return Pager(
            config = PagingConfig(
                pageSize = 50,
                enablePlaceholders = true,
                maxSize = 200
            ),
            pagingSourceFactory = { dao.searchContactsByPhonePattern(pattern) }
        ).flow
    }

    suspend fun insert(contact: Contact) = dao.insert(contact)

    suspend fun update(contact: Contact) = dao.update(contact)

    suspend fun delete(contact: Contact) = dao.delete(contact)

    suspend fun deleteAll() = dao.deleteAll()

    /**
     * وارد کردن دسته‌ای مخاطبین (برای فایل‌های VCF بزرگ).
     * درج در بچ‌های ۵۰۰ تایی برای جلوگیری از فشار زیاد به حافظه و تراکنش‌های بسیار بزرگ.
     */
    suspend fun insertContactsBatch(contacts: List<Contact>, batchSize: Int = 500) {
        contacts.chunked(batchSize).forEach { chunk ->
            dao.insertAll(chunk)
        }
    }

    suspend fun getContactCountOnce(): Int = dao.getContactCountOnce()

    suspend fun getAllContactsForExport(): List<Contact> {
        val total = dao.getContactCountOnce()
        val result = ArrayList<Contact>(total)
        var offset = 0
        val batch = 1000
        while (true) {
            val page = dao.getContactsBatch(batch, offset)
            if (page.isEmpty()) break
            result.addAll(page)
            offset += batch
        }
        return result
    }
}
