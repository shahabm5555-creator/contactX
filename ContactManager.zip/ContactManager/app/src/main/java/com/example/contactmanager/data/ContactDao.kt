package com.example.contactmanager.data

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ContactDao {

    // درج یک مخاطب - در صورت تکراری بودن، نادیده گرفته می‌شود
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(contact: Contact): Long

    // درج دسته‌ای برای وارد کردن سریع فایل‌های VCF بزرگ
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(contacts: List<Contact>)

    @Update
    suspend fun update(contact: Contact)

    @Delete
    suspend fun delete(contact: Contact)

    @Query("DELETE FROM contacts WHERE id = :contactId")
    suspend fun deleteById(contactId: Long)

    @Query("DELETE FROM contacts")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM contacts")
    fun getContactCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM contacts")
    suspend fun getContactCountOnce(): Int

    // منبع صفحه‌بندی‌شده برای نمایش لیست بزرگ مخاطبین بدون فشار به حافظه
    @Query("SELECT * FROM contacts ORDER BY name COLLATE NOCASE ASC")
    fun getAllContactsPaged(): PagingSource<Int, Contact>

    // جستجوی پیشرفته بر اساس نام یا شماره تلفن، صفحه‌بندی‌شده
    @Query(
        """
        SELECT * FROM contacts 
        WHERE name LIKE '%' || :query || '%' 
           OR phone LIKE '%' || :query || '%'
        ORDER BY name COLLATE NOCASE ASC
        """
    )
    fun searchContactsPaged(query: String): PagingSource<Int, Contact>

    // جستجوی الگویی شماره تلفن: هر '_' در pattern دقیقاً معادل یک رقم ناشناخته است
    // (مثلاً 091454___11 یعنی سه رقم وسط هر چیزی می‌تواند باشد)
    @Query(
        """
        SELECT * FROM contacts 
        WHERE phone LIKE :pattern ESCAPE '\'
        ORDER BY name COLLATE NOCASE ASC
        """
    )
    fun searchContactsByPhonePattern(pattern: String): PagingSource<Int, Contact>

    @Query("SELECT * FROM contacts WHERE phone = :phone LIMIT 1")
    suspend fun findByPhone(phone: String): Contact?

    @Query("SELECT * FROM contacts ORDER BY id ASC LIMIT :limit OFFSET :offset")
    suspend fun getContactsBatch(limit: Int, offset: Int): List<Contact>
}
