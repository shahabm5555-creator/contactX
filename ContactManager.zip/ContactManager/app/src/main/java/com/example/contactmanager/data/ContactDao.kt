package com.example.contactmanager.data

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ContactDao {

    // درج یک مخاطب - در صورت تکراری بودن، نادیده گرفته می‌شود
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(contact: Contact): Long

    // درج دسته‌ای برای وارد کردن سریع فایل‌های VCF بزرگ
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(contacts: List<Contact>)

    @Update
    suspend fun update(contact: Contact)

    @Delete
    suspend fun delete(contact: Contact)

    @Query("DELETE FROM contacts WHERE id = :contactId")
    suspend fun deleteById(contactId: Long)

    @Query("DELETE FROM contacts")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM contacts")
    fun getContactCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM contacts")
    suspend fun getContactCountOnce(): Int

    // منبع صفحه‌بندی‌شده برای نمایش لیست بزرگ مخاطبین بدون فشار به حافظه
    @Query("SELECT * FROM contacts ORDER BY name COLLATE NOCASE ASC")
    fun getAllContactsPaged(): PagingSource<Int, Contact>

    // جستجوی پیشرفته بر اساس نام یا شماره تلفن، صفحه‌بندی‌شده.
    // برای شماره، آخرین ۱۰ رقم مقایسه می‌شود تا تفاوت +98 و 0 در ابتدای شماره اهمیتی نداشته باشد
    // مثال: هم +989194063450 و هم 09194063450 با جستجوی 9194063450 پیدا می‌شوند
    @Query(
        """
        SELECT * FROM contacts 
        WHERE name LIKE '%' || :query || '%' 
           OR phone LIKE '%' || :query || '%'
           OR substr(REPLACE(REPLACE(phone, '+', ''), ' ', ''), -10) LIKE '%' || :phoneDigits || '%'
        ORDER BY name COLLATE NOCASE ASC
        """
    )
    fun searchContactsPaged(query: String, phoneDigits: String): PagingSource<Int, Contact>

    // جستجوی الگویی شماره تلفن: هر '_' در pattern دقیقاً معادل یک رقم ناشناخته است.
    // مقایسه روی «آخرین ارقام نرمال‌شده شماره» (بدون + و بدون صفر ابتدایی/کد کشور) انجام می‌شود
    // تا فرقی نکند مخاطب با +98 ذخیره شده یا با 0 - مثال: 914xxx2111 یا 9145xxxxx1
    @Query(
        """
        SELECT * FROM contacts 
        WHERE substr(
                substr(REPLACE(REPLACE(phone, '+', ''), ' ', ''), -10),
                -:patternLength
              ) LIKE :pattern ESCAPE '\'
        ORDER BY name COLLATE NOCASE ASC
        """
    )
    fun searchContactsByPhonePattern(pattern: String, patternLength: Int): PagingSource<Int, Contact>

    @Query("SELECT * FROM contacts WHERE phone = :phone LIMIT 1")
    suspend fun findByPhone(phone: String): Contact?

    @Query("SELECT * FROM contacts ORDER BY id ASC LIMIT :limit OFFSET :offset")
    suspend fun getContactsBatch(limit: Int, offset: Int): List<Contact>
}
