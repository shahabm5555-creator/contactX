package com.example.contactmanager.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.contactmanager.R
import com.example.contactmanager.data.Contact
import com.example.contactmanager.databinding.ItemContactBinding

class ContactAdapter(
    private val onItemClick: (Contact) -> Unit,
    private val onDeleteClick: (Contact) -> Unit,
    private val onItemLongClick: (Contact) -> Unit,
    private val onSelectionChanged: () -> Unit
) : PagingDataAdapter<Contact, ContactAdapter.ContactViewHolder>(DIFF_CALLBACK) {

    private val selectedIds = mutableSetOf<Long>()

    var selectionModeEnabled: Boolean = false
        private set

    /** شروع حالت انتخاب دسته‌جمعی، با انتخاب اولین آیتمی که روی آن Long-press شده */
    fun enterSelectionMode(initialId: Long) {
        selectionModeEnabled = true
        selectedIds.add(initialId)
        notifyItemRangeChanged(0, itemCount)
    }

    /** خروج از حالت انتخاب دسته‌جمعی و پاک کردن انتخاب‌ها */
    fun exitSelectionMode() {
        selectionModeEnabled = false
        selectedIds.clear()
        notifyItemRangeChanged(0, itemCount)
    }

    fun getSelectedIds(): List<Long> = selectedIds.toList()

    fun getSelectedCount(): Int = selectedIds.size

    private fun toggleSelection(id: Long) {
        if (selectedIds.contains(id)) selectedIds.remove(id) else selectedIds.add(id)
    }

    inner class ContactViewHolder(private val binding: ItemContactBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(contact: Contact) {
            binding.textName.text = contact.name
            binding.textPhone.text = contact.phone
            binding.avatarCircle.text = contact.name.trim().firstOrNull()?.uppercase() ?: "?"

            val isSelected = selectedIds.contains(contact.id)
            val context = binding.root.context

            if (selectionModeEnabled) {
                binding.buttonDelete.visibility = android.view.View.GONE
                binding.checkboxSelect.visibility = android.view.View.VISIBLE
                binding.checkboxSelect.isChecked = isSelected
                binding.root.setBackgroundColor(
                    if (isSelected) ContextCompat.getColor(context, R.color.selection_highlight)
                    else Color.TRANSPARENT
                )
                binding.root.setOnClickListener {
                    toggleSelection(contact.id)
                    notifyItemChanged(bindingAdapterPosition)
                    onSelectionChanged()
                }
                binding.root.setOnLongClickListener { true }
            } else {
                binding.buttonDelete.visibility = android.view.View.VISIBLE
                binding.checkboxSelect.visibility = android.view.View.GONE
                val typedValue = android.util.TypedValue()
                context.theme.resolveAttribute(android.R.attr.selectableItemBackground, typedValue, true)
                binding.root.setBackgroundResource(typedValue.resourceId)
                binding.root.setOnClickListener { onItemClick(contact) }
                binding.buttonDelete.setOnClickListener { onDeleteClick(contact) }
                binding.root.setOnLongClickListener {
                    onItemLongClick(contact)
                    true
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val binding = ItemContactBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ContactViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        val contact = getItem(position)
        if (contact != null) holder.bind(contact)
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Contact>() {
            override fun areItemsTheSame(oldItem: Contact, newItem: Contact): Boolean =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: Contact, newItem: Contact): Boolean =
                oldItem == newItem
        }
    }
}
