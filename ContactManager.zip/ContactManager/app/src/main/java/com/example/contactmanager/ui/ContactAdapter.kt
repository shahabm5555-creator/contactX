package com.example.contactmanager.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.contactmanager.R
import com.example.contactmanager.data.Contact
import com.example.contactmanager.databinding.ItemContactBinding
import kotlin.math.abs

class ContactAdapter(
    private val onItemClick: (Contact) -> Unit,
    private val onDeleteClick: (Contact) -> Unit,
    private val onItemLongClick: (Contact) -> Unit,
    private val onSelectionChanged: () -> Unit
) : PagingDataAdapter<Contact, ContactAdapter.ContactViewHolder>(DIFF_CALLBACK) {

    private val selectedIds = mutableSetOf<Long>()

    var selectionModeEnabled: Boolean = false
        private set

    /**
     * شروع حالت انتخاب دسته‌جمعی، با انتخاب اولین آیتمی که روی آن Long-press شده.
     * توجه: رفرش ظاهری آیتم‌های در حال نمایش برعهده MainActivity است (فقط رنج قابل‌مشاهده،
     * نه کل چند ده‌هزار آیتم) تا در لیست‌های بزرگ مشکلی در layout ایجاد نشود.
     */
    fun enterSelectionMode(initialId: Long) {
        selectionModeEnabled = true
        selectedIds.add(initialId)
    }

    /** خروج از حالت انتخاب دسته‌جمعی و پاک کردن انتخاب‌ها */
    fun exitSelectionMode() {
        selectionModeEnabled = false
        selectedIds.clear()
    }

    fun getSelectedIds(): List<Long> = selectedIds.toList()

    fun getSelectedCount(): Int = selectedIds.size

    private fun toggleSelection(id: Long) {
        if (selectedIds.contains(id)) selectedIds.remove(id) else selectedIds.add(id)
    }

    inner class ContactViewHolder(private val binding: ItemContactBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(contact: Contact) {
            binding.textName.text = contact.name
            binding.textPhone.text = contact.phone
            binding.avatarCircle.text = contact.name.trim().firstOrNull()?.uppercase() ?: "?"

            val context = binding.root.context
            binding.avatarCircle.background?.mutate()?.let { drawable ->
                if (drawable is android.graphics.drawable.GradientDrawable) {
                    drawable.setColor(avatarColorFor(contact.phone, context))
                }
            }

            val isSelected = selectedIds.contains(contact.id)

            if (selectionModeEnabled) {
                binding.buttonDelete.visibility = View.GONE
                binding.checkboxSelect.visibility = View.VISIBLE
                binding.checkboxSelect.setImageResource(
                    if (isSelected) R.drawable.ic_check_circle_filled
                    else R.drawable.ic_check_circle_outline
                )
                binding.root.setBackgroundResource(
                    if (isSelected) R.drawable.bg_item_selected else android.R.color.transparent
                )
                binding.root.setOnClickListener {
                    toggleSelection(contact.id)
                    notifyItemChanged(bindingAdapterPosition)
                    onSelectionChanged()
                }
                binding.root.setOnLongClickListener { true }
            } else {
                binding.buttonDelete.visibility = View.VISIBLE
                binding.checkboxSelect.visibility = View.GONE
                val typedValue = android.util.TypedValue()
                context.theme.resolveAttribute(android.R.attr.selectableItemBackground, typedValue, true)
                binding.root.setBackgroundResource(typedValue.resourceId)
                binding.root.setOnClickListener { onItemClick(contact) }
                binding.buttonDelete.setOnClickListener { onDeleteClick(contact) }
                binding.root.setOnLongClickListener {
                    onItemLongClick(contact)
                    true
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val binding = ItemContactBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ContactViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        val contact = getItem(position)
        if (contact != null) holder.bind(contact)
    }

    companion object {
        // پالت رنگی ملایم و متنوع برای آواتار مخاطبین (بر اساس شماره تلفن هش می‌شود)
        private val AVATAR_PALETTE = intArrayOf(
            0xFF049A8F.toInt(), // تیل اصلی برند
            0xFF0984E3.toInt(), // آبی
            0xFF6C5CE7.toInt(), // بنفش
            0xFFE17055.toInt(), // نارنجی ملایم
            0xFF00B894.toInt(), // سبز
            0xFFD63384.toInt(), // صورتی
            0xFF636E72.toInt(), // خاکستری تیره
            0xFF0FB9B1.toInt()  // فیروزه‌ای
        )

        fun avatarColorFor(phone: String, context: android.content.Context): Int {
            val hash = abs(phone.hashCode())
            return AVATAR_PALETTE[hash % AVATAR_PALETTE.size]
        }

        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Contact>() {
            override fun areItemsTheSame(oldItem: Contact, newItem: Contact): Boolean =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: Contact, newItem: Contact): Boolean =
                oldItem == newItem
        }
    }
}
